import sys

import numpy as np

import maccel

from utils_v11 import preprocess_yolo, YoloPostProcess
from visualize_v11 import YoloVisualizer

YOLO_MXQ_PATH = 'modified_best_yolo200.mxq'
DATASET = [
    'coco_sample/img/000000003538.jpg',
    'coco_sample/img/000000009878.jpg',
]

def main(args):
    acc = maccel.Accelerator()
    model = maccel.Model(YOLO_MXQ_PATH)
    model.launch(acc)
    
    postprocess = YoloPostProcess()
    visualizer = YoloVisualizer()
    
    for file_path in DATASET:
        file_name = file_path.split("/")[-1]
        img = preprocess_yolo(file_path)
        img = np.expand_dims(np.transpose(img, [2, 0, 1]), 0)
        outputs = model.infer([img])
        result = postprocess.run(outputs)
        visualizer.save(result, input_path=file_path, output_path=f"output/{file_name}")
    
    model.dispose()

if __name__ == '__main__':
    main(sys.argv)
